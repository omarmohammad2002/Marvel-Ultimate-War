package views;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;

import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import engine.Game;
import engine.Player;
import engine.PriorityQueue;
import model.world.Champion;
import model.world.Cover;
import model.world.Damageable;

public class GameFrame extends JFrame {

	// private JFrame MainFrame;
	private JPanel MainPanel;
	JPanel LeftPanel;
	JPanel TurnOrder;
	
	JTextField x;
	JTextField y;

	private controller listener;

	private JTextField P1Name;
	private JTextField P2Name;

	private JTextArea info;

	public JTextField getP1Name() {
		return P1Name;
	}

	public void setP1Name(JTextField p1Name) {
		P1Name = p1Name;
	}

	public JTextField getP2Name() {
		return P2Name;
	}

	public void setP2Name(JTextField p2Name) {
		P2Name = p2Name;
	}

	public void updateInfo(String s) {
		info.setText(s);
		revalidate();
		repaint();
	}

	public GameFrame() {

		setTitle("Marvel - Ultimate War");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setResizable(false);
		setVisible(true);
		setExtendedState(JFrame.MAXIMIZED_BOTH);

		MainPanel = new JPanel();
		MainPanel.setLayout(null);
		MainPanel.setBackground(Color.BLACK);
		add(MainPanel);

	}

	public void setListener(controller c) {
		listener = c;
	}

	public void setMain() {

		JButton Start; // start button

		JLabel gameTitle = new JLabel();
		gameTitle.setText("Marvel-Ultimate War");
		gameTitle.setBounds(375, 100, 700, 150);
		gameTitle.setFont(new Font("Arial", Font.PLAIN, 60));

		Start = new JButton();
		Start.setName("start_1");
		Start.setText("START");
		Start.addActionListener(listener);
		Start.setBounds(550, 550, 175, 75);
		Start.setFocusable(false);
		Start.setBackground(Color.white);

		MainPanel.add(gameTitle);
		MainPanel.add(Start);

		revalidate();
		repaint();

	}

	public void setPlayers() {
		JButton P1; // player one label, name, and submit button
		JButton P1Submit;

		JButton P2; // player two label, name, and submit button
		JButton P2Submit;

		P1 = new JButton();
		P1.setText("PLAYER 1");
		P1.setBounds(100, 100, 175, 50);
		P1.setFocusable(false);
		P1.setBackground(Color.white);
		MainPanel.add(P1);

		P1Name = new JTextField();
		P1Name.setBounds(100, 160, 175, 50);
		MainPanel.add(P1Name);

		P2 = new JButton();
		P2.setText("PLAYER 2");
		P2.setBounds(1000, 100, 175, 50);
		P2.setFocusable(false);
		P2.setBackground(Color.white);
		MainPanel.add(P2);

		P2Name = new JTextField();
		P2Name.setBounds(1000, 160, 175, 50);
		MainPanel.add(P2Name);

		JButton Continue; // continue button to choose champs
		Continue = new JButton();
		Continue.setText("CONTINUE");
		Continue.setName("Continue_2");
		Continue.setBounds(550, 550, 175, 75);
		Continue.setFocusable(false);
		Continue.setBackground(Color.white);
		Continue.addActionListener(listener);
		MainPanel.add(Continue);

		JLabel gameTitle = new JLabel();
		gameTitle.setText("Marvel-Ultimate War");
		gameTitle.setBounds(375, 100, 700, 150);
		gameTitle.setFont(new Font("Arial", Font.PLAIN, 60));
		MainPanel.add(gameTitle);

	}

	public void setChampionsP1(String name1) {
		MainPanel.setLayout(new BorderLayout());
		JLabel Name1Title = new JLabel();
		MainPanel.setBackground(Color.white);
		Name1Title.setPreferredSize(new Dimension(MainPanel.getWidth(), 125));
		Name1Title.setText(name1 + " please choose 3 champions!");
		Name1Title.setFont(new Font("Arial", Font.PLAIN, 50));
		Name1Title.setHorizontalAlignment(JLabel.CENTER);
		MainPanel.add(Name1Title, BorderLayout.NORTH);

		info = new JTextArea();
		info.setPreferredSize(new Dimension(350, 500));
		info.setFont(new Font("Arial", Font.PLAIN, 9));
		info.setEditable(false);
		MainPanel.add(info, BorderLayout.EAST);

		JPanel ChampionsGrid = new JPanel();
		ChampionsGrid.setLayout(new GridLayout(3, 5));
		MainPanel.add(ChampionsGrid, BorderLayout.CENTER);

		for (int i = 0; i < 15; i++) {
			JButton CurrentChampion = new JButton();
			String ChampionName = Game.getAvailableChampions().get(i).getName();
			CurrentChampion.addActionListener(listener);
			CurrentChampion.addMouseListener(listener);
			CurrentChampion.setText(ChampionName);
			CurrentChampion.setName("ChooseChamp1_" + ChampionName);
			CurrentChampion.setBackground(Color.white);

			ChampionsGrid.add(CurrentChampion);

		}

		JButton Continue;
		Continue = new JButton();
		Continue.setText("CONTINUE");
		Continue.setName("Continue_3");
		Continue.setFocusable(false);
		Continue.setBackground(Color.white);
		Continue.setPreferredSize(new Dimension(MainPanel.getWidth(), 100));
		Continue.addActionListener(listener);
		MainPanel.add(Continue, BorderLayout.SOUTH);

		revalidate();
		repaint();

	}

	public void setChampionsP2(String name2) {
		MainPanel.setLayout(new BorderLayout());
		JLabel Name1Title = new JLabel();
		MainPanel.setBackground(Color.white);
		Name1Title.setPreferredSize(new Dimension(MainPanel.getWidth(), 125));
		Name1Title.setText(name2 + " please choose 3 champions!");
		Name1Title.setFont(new Font("Arial", Font.PLAIN, 50));
		Name1Title.setHorizontalAlignment(JLabel.CENTER);
		MainPanel.add(Name1Title, BorderLayout.NORTH);

		info = new JTextArea();
		info.setPreferredSize(new Dimension(350, 500));
		info.setFont(new Font("Arial", Font.PLAIN, 9));
		info.setEditable(false);
		MainPanel.add(info, BorderLayout.EAST);

		JPanel ChampionsGrid = new JPanel();
		ChampionsGrid.setLayout(new GridLayout(3, 5));
		MainPanel.add(ChampionsGrid, BorderLayout.CENTER);

		for (int i = 0; i < 12; i++) {
			JButton CurrentChampion = new JButton();
			String ChampionName = Game.getAvailableChampions().get(i).getName();
			CurrentChampion.addActionListener(listener);
			CurrentChampion.addMouseListener(listener);
			CurrentChampion.setText(ChampionName);
			CurrentChampion.setName("ChooseChamp2_" + ChampionName);
			CurrentChampion.setBackground(Color.white);

			ChampionsGrid.add(CurrentChampion);

		}

		JButton Continue;
		Continue = new JButton();
		Continue.setText("CONTINUE");
		Continue.setName("Continue_4");
		Continue.setFocusable(false);
		Continue.setBackground(Color.white);
		Continue.setPreferredSize(new Dimension(MainPanel.getWidth(), 100));
		Continue.addActionListener(listener);
		MainPanel.add(Continue, BorderLayout.SOUTH);

		revalidate();
		repaint();

	}

	public void clear() {
		MainPanel.removeAll();
		revalidate();
		repaint();
	}

	public void setLeadersP1(String name1, Game Game) {

		MainPanel.setLayout(new BorderLayout());
		JLabel Name1Title = new JLabel();
		MainPanel.setBackground(Color.white);
		Name1Title.setPreferredSize(new Dimension(MainPanel.getWidth(), 125));
		Name1Title.setText(name1 + " choose your leader!");
		Name1Title.setFont(new Font("Arial", Font.PLAIN, 50));
		Name1Title.setHorizontalAlignment(JLabel.CENTER);
		MainPanel.add(Name1Title, BorderLayout.NORTH);

		JPanel ChampionsGrid = new JPanel();
		ChampionsGrid.setLayout(new GridLayout(3, 1));
		MainPanel.add(ChampionsGrid, BorderLayout.CENTER);

		for (int i = 0; i < 3; i++) {
			JButton CurrentChampion = new JButton();
			Player Player1;
			Player1 = Game.getFirstPlayer();
			String ChampionName = Game.getFirstPlayer().getTeam().get(i).getName();
			CurrentChampion.addActionListener(listener);
			// CurrentChampion.addMouseListener(listener);
			CurrentChampion.setText(ChampionName);
			CurrentChampion.setName("ChooseLeader1_" + ChampionName);
			CurrentChampion.setBackground(Color.white);
			ChampionsGrid.add(CurrentChampion);

		}
		JButton Continue;
		Continue = new JButton();
		Continue.setText("CONTINUE");
		Continue.setName("Continue_5");
		Continue.setFocusable(false);
		Continue.setBackground(Color.white);
		Continue.setPreferredSize(new Dimension(MainPanel.getWidth(), 100));
		Continue.addActionListener(listener);
		MainPanel.add(Continue, BorderLayout.SOUTH);

		revalidate();
		repaint();

	}

	public void setLeadersP2(String name1, Game Game) {

		MainPanel.setLayout(new BorderLayout());
		JLabel Name1Title = new JLabel();
		MainPanel.setBackground(Color.white);
		Name1Title.setPreferredSize(new Dimension(MainPanel.getWidth(), 125));
		Name1Title.setText(name1 + " choose your leader!");
		Name1Title.setFont(new Font("Arial", Font.PLAIN, 50));
		Name1Title.setHorizontalAlignment(JLabel.CENTER);
		MainPanel.add(Name1Title, BorderLayout.NORTH);

		JPanel ChampionsGrid = new JPanel();
		ChampionsGrid.setLayout(new GridLayout(3, 1));
		MainPanel.add(ChampionsGrid, BorderLayout.CENTER);

		for (int i = 0; i < 3; i++) {
			JButton CurrentChampion = new JButton();
			Player Player1;
			Player1 = Game.getSecondPlayer();
			String ChampionName = Game.getSecondPlayer().getTeam().get(i).getName();
			CurrentChampion.addActionListener(listener);
			// CurrentChampion.addMouseListener(listener);
			CurrentChampion.setText(ChampionName);
			CurrentChampion.setName("ChooseLeader2_" + ChampionName);
			CurrentChampion.setBackground(Color.white);
			ChampionsGrid.add(CurrentChampion);

		}
		JButton Continue;
		Continue = new JButton();
		Continue.setText("CONTINUE");
		Continue.setName("Continue_6");
		Continue.setFocusable(false);
		Continue.setBackground(Color.white);
		Continue.setPreferredSize(new Dimension(MainPanel.getWidth(), 100));
		Continue.addActionListener(listener);
		MainPanel.add(Continue, BorderLayout.SOUTH);

		revalidate();
		repaint();

	}

	public void GameTillEnd(Game model) {
		JPanel GameGrid = new JPanel();
		GameGrid = UpdateBoard(model, GameGrid);
		MainPanel.add(GameGrid, BorderLayout.CENTER);

		JPanel RightPanel = new JPanel();
		RightPanel.setPreferredSize(new Dimension(275, MainPanel.getHeight()));
		RightPanel.setBackground(new Color(0, 0, 100));
		MainPanel.add(RightPanel, BorderLayout.EAST);

		JButton P1NAME = new JButton();
		P1NAME.setText(model.getFirstPlayer().getName());
		P1NAME.setBackground(new Color(100, 0, 0));
		P1NAME.setForeground(Color.white);
		RightPanel.add(P1NAME, BorderLayout.NORTH);

		JButton P1LEADER = new JButton();
		P1LEADER.setText("USE LEADER ABILITY");
		P1LEADER.setBackground(Color.white);
		RightPanel.add(P1LEADER, BorderLayout.NORTH);
		P1LEADER.addActionListener(listener);
		P1LEADER.setName("P1LEADER");

		JTextArea CURRENTABILITIESDETAILS = new JTextArea();
		CURRENTABILITIESDETAILS.setBackground(Color.white);
		CURRENTABILITIESDETAILS.setPreferredSize(new Dimension(275, 500));
		CURRENTABILITIESDETAILS.setText(model.getCurrentChampion().getAbilities().toString());
		CURRENTABILITIESDETAILS.setEditable(false);
		RightPanel.add(CURRENTABILITIESDETAILS, BorderLayout.WEST);
		
		 x = new JTextField();
		x.setBackground(Color.GRAY);
		x.setText("x");
		x.setPreferredSize(new Dimension(30,30));
		RightPanel.add(x, BorderLayout.SOUTH);
		
		 y = new JTextField();
		y.setBackground(Color.GRAY);
		y.setText("y");
		y.setPreferredSize(new Dimension(30,30));
		RightPanel.add(y, BorderLayout.SOUTH);
		
		

//		JButton CASTABILITY1 = new JButton();
//		CASTABILITY1.setName("CASTABILITY1");
//		CASTABILITY1.setText("CAST 1ST ABILITY ");
//		CASTABILITY1.setBackground(Color.white);
//		RightPanel.add(CASTABILITY1, BorderLayout.EAST);
//
//		JButton CASTABILITY2 = new JButton();
//		CASTABILITY2.setName("CASTABILITY2");
//		CASTABILITY2.setText(" CAST 2ND ABILITY");
//		CASTABILITY2.setBackground(Color.white);
//		RightPanel.add(CASTABILITY2, BorderLayout.EAST);
//
//		JButton CASTABILITY3 = new JButton();
//		CASTABILITY3.setName("CASTABILITY3");
//		CASTABILITY3.setText("CAST 3RD ABILITY");
//		CASTABILITY3.setBackground(Color.white);
//		RightPanel.add(CASTABILITY3, BorderLayout.EAST);

		JButton UP = new JButton();
		UP.setText("UP");
		UP.setBackground(Color.white);
		RightPanel.add(UP, BorderLayout.SOUTH);

		JButton DOWN = new JButton();
		DOWN.setText("DOWN");
		DOWN.setBackground(Color.white);
		RightPanel.add(DOWN, BorderLayout.SOUTH);

		JButton LEFT = new JButton();
		LEFT.setText("LEFT");
		LEFT.setBackground(Color.white);
		RightPanel.add(LEFT, BorderLayout.SOUTH);

		JButton RIGHT = new JButton();
		RIGHT.setText("RIGHT");
		RIGHT.setBackground(Color.white);
		RightPanel.add(RIGHT, BorderLayout.SOUTH);

		DOWN.addActionListener(listener);
		UP.addActionListener(listener);
		RIGHT.addActionListener(listener);
		LEFT.addActionListener(listener);

		UP.setName("UP");
		LEFT.setName("LEFT");
		RIGHT.setName("RIGHT");
		DOWN.setName("DOWN");

		 LeftPanel = new JPanel();
		LeftPanel.setPreferredSize(new Dimension(200, MainPanel.getHeight()));
		LeftPanel.setBackground(new Color(100, 0, 0));
		MainPanel.add(LeftPanel, BorderLayout.WEST);

		JButton P2NAME = new JButton();
		P2NAME.setText(model.getSecondPlayer().getName());
		P2NAME.setBackground(new Color(0, 0, 100));
		P2NAME.setForeground(Color.white);
		LeftPanel.add(P2NAME, BorderLayout.NORTH);

		JTextArea CURRENTCHAMPDETAILS = new JTextArea();
		CURRENTCHAMPDETAILS.setBackground(Color.white);
		CURRENTCHAMPDETAILS.setPreferredSize(new Dimension(200, 150));
		String s = model.getCurrentChampion().toString2() + "Is Leader:" + model.isLeader(model.getCurrentChampion());
		CURRENTCHAMPDETAILS.setText(s);
		CURRENTCHAMPDETAILS.setEditable(false);
		LeftPanel.add(CURRENTCHAMPDETAILS, BorderLayout.CENTER);

		JButton ATTACKRIGHT = new JButton();
		ATTACKRIGHT.setText("ATTACKRIGHT");
		ATTACKRIGHT.setName("ATTACKRIGHT");
		ATTACKRIGHT.setBackground(Color.white);
		LeftPanel.add(ATTACKRIGHT, BorderLayout.CENTER);

		JButton ATTACKLEFT = new JButton();
		ATTACKLEFT.setText("ATTACKLEFT");
		ATTACKLEFT.setName("ATTACKLEFT");
		ATTACKLEFT.setBackground(Color.white);
		LeftPanel.add(ATTACKLEFT, BorderLayout.CENTER);

		JButton ATTACKUP = new JButton();
		ATTACKUP.setText("ATTACKUP");
		ATTACKUP.setName("ATTACKUP");
		ATTACKUP.setBackground(Color.white);
		LeftPanel.add(ATTACKUP, BorderLayout.CENTER);

		JButton ATTACKDOWN = new JButton();
		ATTACKDOWN.setText("ATTACKDOWN");
		ATTACKDOWN.setName("ATTACKDOWN");
		ATTACKDOWN.setBackground(Color.white);
		LeftPanel.add(ATTACKDOWN, BorderLayout.CENTER);

		ATTACKDOWN.addActionListener(listener);
		ATTACKUP.addActionListener(listener);
		ATTACKRIGHT.addActionListener(listener);
		ATTACKLEFT.addActionListener(listener);

		JButton ENDTURN = new JButton();
		ENDTURN.setName("ENDTURN");
		ENDTURN.setText("END TURN");
		ENDTURN.addActionListener(listener);
		ENDTURN.setBackground(Color.white);
		LeftPanel.add(ENDTURN, BorderLayout.CENTER);
		
		JPanel ABNUMBER = new JPanel();
		ABNUMBER.setLayout(new GridLayout(1, 3));
		for(int i = 1; i<=3; i++) {
			JButton button = new JButton();
			if(i==1) {
				button.setName("c1");
				button.setText("1");
				button.addActionListener(listener);
			}
			if(i==2) {
				button.setName("c2");
				button.setText("2");
				button.addActionListener(listener);
			}
			if(i==3) {
				button.setName("c3");
				button.setText("3");
				button.addActionListener(listener);
			}
			button.setBackground(Color.white);
			ABNUMBER.add(button);
		}
		LeftPanel.add(ABNUMBER, BorderLayout.SOUTH);
		
		JPanel ABDIRECTION = new JPanel();
		ABDIRECTION.setLayout(new GridLayout(4,1));
		for(int i = 1; i<=4; i++) {
			JButton button = new JButton();
			if(i==1) {
				button.setName("UPCAST");
				button.setText("UP");
				button.addActionListener(listener);
			}
			if(i==2) {
				button.setName("DOWNCAST");
				button.setText("DOWN");
				button.addActionListener(listener);
			}
			if(i==3) {
				button.setName("LEFTCAST");
				button.setText("LEFT");
				button.addActionListener(listener);
			}
			if(i==4) {
				button.setName("RIGHTCAST");
				button.setText("RIGHT");
				button.addActionListener(listener);
			}
			button.setBackground(Color.white);
			ABDIRECTION.add(button);
		}
		LeftPanel.add(ABDIRECTION, BorderLayout.SOUTH);
		
		JButton CASTABILITY = new JButton();
		CASTABILITY.setName("CASTABILITY");
		CASTABILITY.setText("CAST ABILITY ");
		CASTABILITY.setBackground(Color.white);
		CASTABILITY.addActionListener(listener);
		LeftPanel.add(CASTABILITY, BorderLayout.SOUTH);
		
		
		

		TurnOrder = new JPanel();
		TurnOrder.setLayout(new GridLayout(6, 1));
		TurnOrder.setBackground(new Color(0, 50, 50));
		UpdatePriorityQ( model);
		LeftPanel.add(TurnOrder, BorderLayout.SOUTH);

		revalidate();
		repaint();
	}

	public JPanel UpdateBoard(Game model, JPanel GameGrid) {
		GameGrid.setLayout(new GridLayout(5, 5));
		Object[][] GameBoard = model.getBoard();
		for (int i = 4; i >= 0; i--) {
			for (int j = 0; j < 5; j++) {
				Damageable x = (Damageable) GameBoard[i][j];
				if (x != null) {
					if (x instanceof Champion) {
						if (model.getFirstPlayer().getTeam().contains(x)) {
							String ChampInfo = ((Champion) x).getName() + '\n' + "   " + "Current HP: "
									+ x.getCurrentHP();
							JTextField ChampComponent = new JTextField();
							ChampComponent.setText(ChampInfo);
							ChampComponent.setBackground(new Color(100, 0, 0));
							ChampComponent.setEditable(false);
							ChampComponent.setForeground(Color.WHITE);
							GameGrid.add(ChampComponent);
							revalidate();
							repaint();
						} else {
							String ChampInfo = ((Champion) x).getName() + '\n' + "   " + "Current HP: "
									+ x.getCurrentHP();
							JTextField ChampComponent = new JTextField();
							ChampComponent.setText(ChampInfo);
							ChampComponent.setBackground(new Color(0, 0, 100));
							ChampComponent.setEditable(false);
							ChampComponent.setForeground(Color.WHITE);
							GameGrid.add(ChampComponent);
							revalidate();
							repaint();
						}
					}
					if (x instanceof Cover) {
						String ChampInfo = "COVER" + '\n' + "   " + "Current HP: " + x.getCurrentHP();
						JTextField ChampComponent = new JTextField();
						ChampComponent.setText(ChampInfo);
						ChampComponent.setEditable(false);
						ChampComponent.setBackground(new Color(0, 80, 80));
						ChampComponent.setForeground(Color.WHITE);
						GameGrid.add(ChampComponent);
						revalidate();
						repaint();
					}
				} else {
					JTextField ChampComponent = new JTextField();
					ChampComponent.setBackground(Color.white);
					ChampComponent.setEditable(false);
					GameGrid.add(ChampComponent);
					revalidate();
					repaint();
				}
			}
			revalidate();
			repaint();
		}
		revalidate();
		repaint();
		return GameGrid;
	}
	public void UpdatePriorityQ(Game model) {
		this.TurnOrder.removeAll();
		PriorityQueue x = new PriorityQueue(6);
		int size = model.getTurnOrder().size();
		for(int i = 0; i<size;i++) {
			x.insert(model.getTurnOrder().remove());
			
		}
		for(int i = 0; i<size; i++) {
			JButton button = new JButton();
			if(i==0) {
				button.setBackground(Color.green);
				
			}
			button.setText(((Champion) x.peekMin()).getName());
			this.TurnOrder.add(button);
			model.getTurnOrder().insert(x.remove());
		}
	}

	public void Gameover(Game model) {

		JButton WINNER = new JButton();
		String s = model.checkGameOver().getName();
		WINNER.setText("Game Over " + s + " is the winner!");
		WINNER.setFont(new Font("Arial", Font.PLAIN, 70));
		WINNER.setName("WINNER");
		WINNER.setBackground(Color.white);
		MainPanel.add(WINNER);
		revalidate();
		repaint();
	}

}
