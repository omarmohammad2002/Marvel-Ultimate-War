package views;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JOptionPane;

import engine.Game;
import engine.Player;
import model.abilities.AreaOfEffect;
import model.world.Champion;
import model.world.Direction;

public class controller implements ActionListener, MouseListener {

	private GameFrame MainFrame;
	private String name1;
	private String name2;
	private Player firstPlayer;
	private Player secondPlayer;
	private Game model;
	private boolean bool1;
	private boolean bool2;
	private boolean bool3;
	private boolean boolup;
	private boolean booldown;
	private boolean boolleft;
	private boolean boolright;

	public controller() throws IOException {
		MainFrame = new GameFrame();
		Game.loadAbilities("Abilities.csv");
		Game.loadChampions("Champions.csv");
		MainFrame.setListener(this);
		MainFrame.setMain();

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() instanceof JButton) {
			JButton button = (JButton) e.getSource();

			if (button.getName().equals("start_1")) {
				MainFrame.clear();
				MainFrame.setPlayers();
			}
			if (button.getName().equals("Continue_2")) {
				name1 = MainFrame.getP1Name().getText();
				name2 = MainFrame.getP2Name().getText();
				if (name1.equals("") || name2.equals(""))
					JOptionPane.showMessageDialog(null, "Please enter names", "Enter names!",
							JOptionPane.PLAIN_MESSAGE);
				else {
					firstPlayer = new Player(name1);
					secondPlayer = new Player(name2);
					MainFrame.clear();
					MainFrame.setChampionsP1(name1);

				}

			}
			if (button.getName().length() >= 12 && button.getName().substring(0, 12).equals("ChooseChamp1")) {
				if (firstPlayer.getTeam().size() == 3) {
					JOptionPane.showMessageDialog(null,
							"Player one team full, time for the second player to choose their champ", "Press continue!",
							JOptionPane.PLAIN_MESSAGE);

				} else {
					String Name = button.getName().substring(13);
					Champion c = null;
					for (int i = 0; i < Game.getAvailableChampions().size(); i++) {
						if (Name.equals(Game.getAvailableChampions().get(i).getName())) {
							c = Game.getAvailableChampions().get(i);
						}
					}
					Game.getAvailableChampions().remove(c);
					firstPlayer.getTeam().add(c);
					button.setEnabled(false);
					button.setOpaque(true);

					MainFrame.revalidate();
					MainFrame.repaint();
				}
			}
			if (button.getName().equals("Continue_3")) {
				if (firstPlayer.getTeam().size() != 3) {
					JOptionPane.showMessageDialog(null, "Please choose 3 champions!", "Choose champions!",
							JOptionPane.PLAIN_MESSAGE);
				} else {
					MainFrame.clear();
					MainFrame.setChampionsP2(name2);
				}

			}
			if (button.getName().equals("Continue_4")) {
				if (secondPlayer.getTeam().size() != 3) {
					JOptionPane.showMessageDialog(null, "Please choose 3 champions!", "Choose champions!",
							JOptionPane.PLAIN_MESSAGE);
				} else {
					MainFrame.clear();
					model = new Game(firstPlayer, secondPlayer);
					MainFrame.setLeadersP1(name1, model);
				}

			}

			if (button.getName().length() >= 12 && button.getName().substring(0, 12).equals("ChooseChamp2")) {
				if (secondPlayer.getTeam().size() == 3) {
					JOptionPane.showMessageDialog(null, "Player 2 team full, time to choose leaders", "Press continue!",
							JOptionPane.PLAIN_MESSAGE);

				} else {
					String Name = button.getName().substring(13);
					Champion c = null;
					for (int i = 0; i < Game.getAvailableChampions().size(); i++) {
						if (Name.equals(Game.getAvailableChampions().get(i).getName())) {
							c = Game.getAvailableChampions().get(i);
						}
					}
					Game.getAvailableChampions().remove(c);
					secondPlayer.getTeam().add(c);
					button.setEnabled(false);
					button.setOpaque(true);

					MainFrame.revalidate();
					MainFrame.repaint();
				}
			}
			if (button.getName().length() >= 13 && button.getName().substring(0, 13).equals("ChooseLeader1")) {
				if (firstPlayer.getLeader() != null) {
					JOptionPane.showMessageDialog(null, "Leader 1 already chosen, time for player2 to choose leader",
							"Press continue!", JOptionPane.PLAIN_MESSAGE);

				} else {
					String Name = button.getName().substring(14);
					Champion c = null;
					for (int i = 0; i < firstPlayer.getTeam().size(); i++) {
						if (Name.equals(firstPlayer.getTeam().get(i).getName())) {
							c = firstPlayer.getTeam().get(i);
						}
					}
					firstPlayer.setLeader(c);
					button.setEnabled(false);
					button.setOpaque(true);

					MainFrame.revalidate();
					MainFrame.repaint();
				}
			}
			if (button.getName().equals("Continue_5")) {
				if (firstPlayer.getLeader() == null) {
					JOptionPane.showMessageDialog(null, name1 + "" + " please choose your Leader!", "Choose a leader!",
							JOptionPane.PLAIN_MESSAGE);
				} else {
					MainFrame.clear();
					MainFrame.setLeadersP2(name2, model);
				}

			}
			if (button.getName().length() >= 13 && button.getName().substring(0, 13).equals("ChooseLeader2")) {
				if (secondPlayer.getLeader() != null) {
					JOptionPane.showMessageDialog(null, "Leaders chosen, time to start the game", "Press continue!",
							JOptionPane.PLAIN_MESSAGE);

				} else {
					String Name = button.getName().substring(14);
					Champion c = null;
					for (int i = 0; i < secondPlayer.getTeam().size(); i++) {
						if (Name.equals(secondPlayer.getTeam().get(i).getName())) {
							c = secondPlayer.getTeam().get(i);
						}
					}
					secondPlayer.setLeader(c);
					button.setEnabled(false);
					button.setOpaque(true);

					MainFrame.revalidate();
					MainFrame.repaint();
				}
			}
			if (button.getName().equals("Continue_6")) {
				if (secondPlayer.getLeader() == null) {
					JOptionPane.showMessageDialog(null, name2 + "" + " please choose your Leader!", "Choose a leader!",
							JOptionPane.PLAIN_MESSAGE);
				} else {
					MainFrame.clear();
					MainFrame.GameTillEnd(model);

				}

			}
			if (button.getName().equals("ENDTURN")) {

				model.endTurn();
				MainFrame.clear();
				MainFrame.GameTillEnd(model);
			}
			if (button.getName().equals("ATTACKUP")) {
				try {
					model.attack(Direction.UP);

				} catch (Exception exception) {
					JOptionPane.showMessageDialog(null, exception.getMessage(), "Stop!", JOptionPane.PLAIN_MESSAGE);
				}
				MainFrame.clear();
				MainFrame.GameTillEnd(model);
			}
			if (button.getName().equals("ATTACKLEFT")) {
				try {
					model.attack(Direction.LEFT);
					MainFrame.clear();
					MainFrame.GameTillEnd(model);

				} catch (Exception exception) {
					JOptionPane.showMessageDialog(null, exception.getMessage(), "Stop!", JOptionPane.PLAIN_MESSAGE);
				}
				MainFrame.clear();
				MainFrame.GameTillEnd(model);
			}
			if (button.getName().equals("ATTACKRIGHT")) {
				try {
					model.attack(Direction.RIGHT);

				} catch (Exception exception) {
					JOptionPane.showMessageDialog(null, exception.getMessage(), "Stop!", JOptionPane.PLAIN_MESSAGE);
				}
				MainFrame.clear();
				MainFrame.GameTillEnd(model);
			}
			if (button.getName().equals("ATTACKDOWN")) {
				try {
					model.attack(Direction.DOWN);
				} catch (Exception exception) {
					JOptionPane.showMessageDialog(null, exception.getMessage(), "Stop!", JOptionPane.PLAIN_MESSAGE);
				}
				MainFrame.clear();
				MainFrame.GameTillEnd(model);

			}
			if (button.getName().equals("UP")) {
				try {
					model.move(Direction.UP);

				} catch (Exception exception) {
					JOptionPane.showMessageDialog(null, exception.getMessage(), "Stop!", JOptionPane.PLAIN_MESSAGE);
				}
				MainFrame.clear();
				MainFrame.GameTillEnd(model);
			}
			if (button.getName().equals("LEFT")) {
				try {
					model.move(Direction.LEFT);
					MainFrame.clear();
					MainFrame.GameTillEnd(model);

				} catch (Exception exception) {
					JOptionPane.showMessageDialog(null, exception.getMessage(), "Stop!", JOptionPane.PLAIN_MESSAGE);
				}
				MainFrame.clear();
				MainFrame.GameTillEnd(model);
			}
			if (button.getName().equals("RIGHT")) {
				try {
					model.move(Direction.RIGHT);

				} catch (Exception exception) {
					JOptionPane.showMessageDialog(null, exception.getMessage(), "Stop!", JOptionPane.PLAIN_MESSAGE);
				}
				MainFrame.clear();
				MainFrame.GameTillEnd(model);
			}
			if (button.getName().equals("DOWN")) {
				try {
					model.move(Direction.DOWN);
				} catch (Exception exception) {
					JOptionPane.showMessageDialog(null, exception.getMessage(), "Stop!", JOptionPane.PLAIN_MESSAGE);
				}
				MainFrame.clear();
				MainFrame.GameTillEnd(model);

			}
			if (model!=null) {
			if (model.checkGameOver() != null) {
				MainFrame.clear();
				MainFrame.Gameover(model);
			}}

			if (button.getName().equals("P1LEADER")) {

				try {
					model.useLeaderAbility();
				} catch (Exception exception) {
					JOptionPane.showMessageDialog(null, exception.getMessage(), "Stop!", JOptionPane.PLAIN_MESSAGE);
				}
				button.setEnabled(false);
				button.setOpaque(true);
				MainFrame.clear();
				MainFrame.GameTillEnd(model);
			}
			if(button.getName().equals("c1")) {
				bool1 = true;
				button.setOpaque(true);
				button.setEnabled(false);}
				if(button.getName().equals("UPCAST")) {
					boolup = true;
					button.setOpaque(true);
					
				}
				if(button.getName().equals("DOWNCAST")) {
					booldown = true;
					button.setOpaque(true);
					
				}
				 if(button.getName().equals("LEFTCAST")) {
					boolleft = true;
					button.setOpaque(true);
					
				}
				if(button.getName().equals("RIGHTCAST")) {
					boolright = true;
					button.setOpaque(true);
					
				}
			
			 if(button.getName().equals("c2")) {
				bool2 = true;
				button.setOpaque(true);
				button.setEnabled(false);}
				if(button.getName().equals("UPCAST")) {
					boolup = true;
					button.setOpaque(true);
					
				}
				if(button.getName().equals("DOWNCAST")) {
					booldown = true;
					button.setOpaque(true);
					
				}
				 if(button.getName().equals("LEFTCAST")) {
					boolleft = true;
					button.setOpaque(true);
					
				}
				if(button.getName().equals("RIGHTCAST")) {
					boolright = true;
					button.setOpaque(true);
					
				}
			
			 if(button.getName().equals("c3")) {
				bool3 = true;
				button.setOpaque(true);}
				
				if(button.getName().equals("UPCAST")) {
					boolup = true;
					button.setOpaque(true);
					
				}
				if(button.getName().equals("DOWNCAST")) {
					booldown = true;
					button.setOpaque(true);
					
				}
				 if(button.getName().equals("LEFTCAST")) {
					boolleft = true;
					button.setOpaque(true);
					
				}
				if(button.getName().equals("RIGHTCAST")) {
					boolright = true;
					button.setOpaque(true);
					
				}
			
		
			if (button.getName().equals("CASTABILITY")) {
				try {
					
					if(bool1 == true) {
						if (model.getCurrentChampion().getAbilities().get(0).getCastArea() == AreaOfEffect.DIRECTIONAL) {
						if(boolup == true) {
							model.castAbility(model.getCurrentChampion().getAbilities().get(0),Direction.UP);
							bool1= false;
							bool2= false;
							bool3= false;

							boolup=false;
							booldown=false;
							boolright=false;
							boolleft=false;
						}
						if(booldown == true) {
							model.castAbility(model.getCurrentChampion().getAbilities().get(0),Direction.DOWN);
							bool1= false;
							bool2= false;
							bool3= false;

							boolup=false;
							booldown=false;
							boolright=false;
							boolleft=false;
						}
						if(boolleft == true) {
							model.castAbility(model.getCurrentChampion().getAbilities().get(0),Direction.LEFT);
							bool1= false;
							bool2= false;
							bool3= false;

							boolup=false;
							booldown=false;
							boolright=false;
							boolleft=false;
						}
						if(boolright == true) {
							model.castAbility(model.getCurrentChampion().getAbilities().get(0),Direction.RIGHT);
							bool1= false;
							bool2= false;
							bool3= false;

							boolup=false;
							booldown=false;
							boolright=false;
							boolleft=false;
						}}
						else	if (model.getCurrentChampion().getAbilities().get(0).getCastArea() == AreaOfEffect.SINGLETARGET) {
							
							bool1= false;
							bool2= false;
							bool3= false;

							boolup=false;
							booldown=false;
							boolright=false;
							boolleft=false;
							model.castAbility(model.getCurrentChampion().getAbilities().get(0),Integer.parseInt(MainFrame.x.getText()),Integer.parseInt(MainFrame.y.getText()));
						}
						else {
							model.castAbility(model.getCurrentChampion().getAbilities().get(0));
							bool1= false;
							bool2= false;
							bool3= false;

							boolup=false;
							booldown=false;
							boolright=false;
							boolleft=false;
						}
					}
					if(bool2==true) {
						if (model.getCurrentChampion().getAbilities().get(1).getCastArea() == AreaOfEffect.DIRECTIONAL) {
							if(boolup == true) {
								model.castAbility(model.getCurrentChampion().getAbilities().get(1),Direction.UP);
								bool1= false;
								bool2= false;
								bool3= false;

								boolup=false;
								booldown=false;
								boolright=false;
								boolleft=false;
							}
							if(booldown == true) {
								model.castAbility(model.getCurrentChampion().getAbilities().get(1),Direction.DOWN);
								bool1= false;
								bool2= false;
								bool3= false;

								boolup=false;
								booldown=false;
								boolright=false;
								boolleft=false;
							}
							if(boolleft == true) {
								model.castAbility(model.getCurrentChampion().getAbilities().get(1),Direction.LEFT);
								bool1= false;
								bool2= false;
								bool3= false;

								boolup=false;
								booldown=false;
								boolright=false;
								boolleft=false;
							}
							if(boolright == true) {
								model.castAbility(model.getCurrentChampion().getAbilities().get(1),Direction.RIGHT);
								bool1= false;
								bool2= false;
								bool3= false;

								boolup=false;
								booldown=false;
								boolright=false;
								boolleft=false;
							}
						}
					else if (model.getCurrentChampion().getAbilities().get(1).getCastArea() == AreaOfEffect.SINGLETARGET) {
						bool1= false;
						bool2= false;
						bool3= false;

						boolup=false;
						booldown=false;
						boolright=false;
						boolleft=false;
						model.castAbility(model.getCurrentChampion().getAbilities().get(1),Integer.parseInt(MainFrame.x.getText()),Integer.parseInt(MainFrame.y.getText()));
						}
						else {
							model.castAbility(model.getCurrentChampion().getAbilities().get(1));
							bool1= false;
							bool2= false;
							bool3= false;

							boolup=false;
							booldown=false;
							boolright=false;
							boolleft=false;
						
					}}
					if(bool3==true) {
						if (model.getCurrentChampion().getAbilities().get(2).getCastArea() == AreaOfEffect.DIRECTIONAL) {
							if(boolup == true) {
								model.castAbility(model.getCurrentChampion().getAbilities().get(2),Direction.UP);
								bool1= false;
								bool2= false;
								bool3= false;

								boolup=false;
								booldown=false;
								boolright=false;
								boolleft=false;
							}
							if(booldown == true) {
								model.castAbility(model.getCurrentChampion().getAbilities().get(2),Direction.DOWN);
								bool1= false;
								bool2= false;
								bool3= false;

								boolup=false;
								booldown=false;
								boolright=false;
								boolleft=false;
							}
							if(boolleft == true) {
								model.castAbility(model.getCurrentChampion().getAbilities().get(2),Direction.LEFT);
								bool1= false;
								bool2= false;
								bool3= false;

								boolup=false;
								booldown=false;
								boolright=false;
								boolleft=false;
							}
							if(boolright == true) {
								model.castAbility(model.getCurrentChampion().getAbilities().get(2),Direction.RIGHT);
								bool1= false;
								bool2= false;
								bool3= false;

								boolup=false;
								booldown=false;
								boolright=false;
								boolleft=false;
							}
						}
						else	if (model.getCurrentChampion().getAbilities().get(2).getCastArea() == AreaOfEffect.SINGLETARGET) {
							bool1= false;
							bool2= false;
							bool3= false;

							boolup=false;
							booldown=false;
							boolright=false;
							boolleft=false;
							model.castAbility(model.getCurrentChampion().getAbilities().get(2),Integer.parseInt(MainFrame.x.getText()),Integer.parseInt(MainFrame.y.getText()));
						}
						else {
							model.castAbility(model.getCurrentChampion().getAbilities().get(2));
							bool1= false;
							bool2= false;
							bool3= false;

							boolup=false;
							booldown=false;
							boolright=false;
							boolleft=false;
						}}
						
					
					


				} catch (Exception exception) {
					JOptionPane.showMessageDialog(null, exception.getMessage(), "Stop!", JOptionPane.PLAIN_MESSAGE);
				}
				MainFrame.clear();
				MainFrame.GameTillEnd(model);

			}
			

		}
	}

	public static void main(String[] args) throws IOException {
		new controller();
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseEntered(MouseEvent e) {
		if (e.getSource() instanceof JButton) {
			JButton button = (JButton) e.getSource();

			if (button.getName().length() >= 12 && button.getName().substring(0, 12).equals("ChooseChamp1")) {
				String Name = button.getName().substring(13);
				Champion c = null;
				for (int i = 0; i < Game.getAvailableChampions().size(); i++) {
					if (Name.equals(Game.getAvailableChampions().get(i).getName())) {
						c = Game.getAvailableChampions().get(i);
					}
				}

				if (c != null)
					MainFrame.updateInfo(c.toString());
				else
					MainFrame.updateInfo("");

			}

			if (button.getName().length() >= 12 && button.getName().substring(0, 12).equals("ChooseChamp2")) {
				String Name = button.getName().substring(13);
				Champion c = null;
				for (int i = 0; i < Game.getAvailableChampions().size(); i++) {
					if (Name.equals(Game.getAvailableChampions().get(i).getName())) {
						c = Game.getAvailableChampions().get(i);
					}
				}

				if (c != null)
					MainFrame.updateInfo(c.toString());
				else
					MainFrame.updateInfo("");

			}

		}

	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub

	}

}
