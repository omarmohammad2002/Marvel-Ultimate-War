package engine;

import java.awt.Point;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

import exceptions.AbilityUseException;
import exceptions.ChampionDisarmedException;
import exceptions.GameActionException;
import exceptions.InvalidTargetException;
import exceptions.LeaderAbilityAlreadyUsedException;
import exceptions.LeaderNotCurrentException;
import exceptions.NotEnoughResourcesException;
import exceptions.UnallowedMovementException;
import model.world.Cover;
import model.world.Damageable;
import model.world.Direction;
import model.world.Hero;
import model.world.Villain;
import model.abilities.Ability;
import model.abilities.AreaOfEffect;
import model.abilities.CrowdControlAbility;
import model.abilities.DamagingAbility;
import model.abilities.HealingAbility;
import model.effects.Effect;
import model.effects.EffectType;
import model.world.AntiHero;
import model.world.Champion;
import model.world.Condition;
import model.effects.*;

public class Game {
	private Player firstPlayer;
	private Player secondPlayer;
	private boolean firstLeaderAbilityUsed;
	private boolean secondLeaderAbilityUsed;
	private Object[][] board;
	private static ArrayList<Champion> availableChampions = new ArrayList<Champion>();
	private static ArrayList<Ability> availableAbilities = new ArrayList<Ability>();
	private PriorityQueue turnOrder;
	private static final int BOARDHEIGHT = 5;
	private static final int BOARDWIDTH = 5;

	public Game(Player first, Player second) {
		this.firstPlayer = first;
		this.secondPlayer = second;
		board = new Object[BOARDHEIGHT][BOARDWIDTH];
		placeCovers();
		placeChampions();
		turnOrder = new PriorityQueue(6);
		prepareChampionTurns();
		availableChampions = new ArrayList<Champion>();
		availableAbilities = new ArrayList<Ability>();

	}

	public Player getFirstPlayer() {
		return firstPlayer;
	}

	public static int getBoardheight() {
		return BOARDHEIGHT;
	}

	public Player getSecondPlayer() {
		return secondPlayer;
	}

	public boolean isFirstLeaderAbilityUsed() {
		return firstLeaderAbilityUsed;
	}

	public boolean isSecondLeaderAbilityUsed() {
		return secondLeaderAbilityUsed;
	}

	public Object[][] getBoard() {
		return board;
	}

	public static ArrayList<Champion> getAvailableChampions() {
		return availableChampions;
	}

	public static ArrayList<Ability> getAvailableAbilities() {
		return availableAbilities;
	}

	public PriorityQueue getTurnOrder() {
		return turnOrder;
	}

	public static int getBoardwidth() {
		return BOARDWIDTH;
	}

	private void placeChampions() {
		if (!this.firstPlayer.getTeam().isEmpty()) {
			for (int i = 1; i <= 3; i++) {
				this.board[0][i] = firstPlayer.getTeam().get(i - 1);
				Point p = new Point(0, i);
				firstPlayer.getTeam().get(i - 1).setLocation(p);

			}

		}
		if (!this.secondPlayer.getTeam().isEmpty()) {
			for (int i = 1; i <= 3; i++) {
				this.board[4][i] = secondPlayer.getTeam().get(i - 1);
				Point p = new Point(4, i);
				secondPlayer.getTeam().get(i - 1).setLocation(p);
			}

		}

	}

	private void placeCovers() {
		for (int i = 0; i < 5; i++) {
			int x = (int) (1 + Math.random() * 3);
			int y = (int) (Math.random() * 5);

			Cover a = new Cover(x, y);
			if (this.board[x][y] == null)
				this.board[x][y] = a;
			else
				i--;
		}
	}

	public static void loadAbilities(String filePath) throws IOException {
		availableAbilities = new ArrayList<Ability>();
		BufferedReader x = new BufferedReader(new FileReader(filePath));
		AreaOfEffect y = null;
		String t;
		while ((t = x.readLine()) != null) {

			String[] c = t.split(",");
			Ability ability = null;
			y = AreaOfEffect.valueOf(c[5]);
			if (c[0].equals("DMG")) {
				ability = new DamagingAbility(c[1], (Integer.parseInt(c[2])), (Integer.parseInt(c[4])),
						(Integer.parseInt(c[3])), y, (Integer.parseInt(c[6])), (Integer.parseInt(c[7])));
			}
			if (c[0].equals("HEL")) {
				ability = new HealingAbility(c[1], (Integer.parseInt(c[2])), (Integer.parseInt(c[4])),
						(Integer.parseInt(c[3])), y, (Integer.parseInt(c[6])), (Integer.parseInt(c[7])));
			}
			if (c[0].equals("CC")) {
				Effect z = findEffectType(c[7], Integer.parseInt(c[8]));
				ability = new CrowdControlAbility(c[1], (Integer.parseInt(c[2])), (Integer.parseInt(c[4])),
						(Integer.parseInt(c[3])), y, (Integer.parseInt(c[6])), z);
			}

			availableAbilities.add(ability);
		}
	}

	public static Effect findEffectType(String name, int d) {
		Effect F = null;
		switch (name) {
		case "Disarm":
			F = new Disarm(d);
			break;
		case "PowerUp":
			F = new PowerUp(d);
			break;
		case "Shield":
			F = new Shield(d);
			break;
		case "Silence":
			F = new Silence(d);
			break;
		case "SpeedUp":
			F = new SpeedUp(d);
			break;
		case "Embrace":
			F = new Embrace(d);
			break;
		case "Root":
			F = new Root(d);
			break;
		case "Shock":
			F = new Shock(d);
			break;
		case "Dodge":
			F = new Dodge(d);
			break;
		case "Stun":
			F = new Stun(d);
			break;
		}
		return F;
	}

	public static void loadChampions(String filePath) throws IOException {
		BufferedReader x = new BufferedReader(new FileReader(filePath));
		availableChampions = new ArrayList<Champion>();
		String t;
		while ((t = x.readLine()) != null) {
			String[] line = t.split(",");
			Champion a = null;
			Ability A = findAblility(line[8]);
			Ability B = findAblility(line[9]);
			Ability C = findAblility(line[10]);
			switch (line[0]) {
			case "V":
				a = new Villain(line[1], Integer.parseInt(line[2]), Integer.parseInt(line[3]),
						Integer.parseInt(line[4]), Integer.parseInt(line[5]), Integer.parseInt(line[6]),
						Integer.parseInt(line[7]));
				break;
			case "A":
				a = new AntiHero(line[1], Integer.parseInt(line[2]), Integer.parseInt(line[3]),
						Integer.parseInt(line[4]), Integer.parseInt(line[5]), Integer.parseInt(line[6]),
						Integer.parseInt(line[7]));
				break;
			case "H":
				a = new Hero(line[1], Integer.parseInt(line[2]), Integer.parseInt(line[3]), Integer.parseInt(line[4]),
						Integer.parseInt(line[5]), Integer.parseInt(line[6]), Integer.parseInt(line[7]));
				break;
			default:
				return;
			}

			a.getAbilities().add(A);
			a.getAbilities().add(B);
			a.getAbilities().add(C);

			availableChampions.add(a);
		}
	}

	private static Ability findAblility(String string) {

		if (availableAbilities == null)
			return null;
		for (int i = 0; i < availableAbilities.size(); i++) {
			if (availableAbilities.get(i).getName().equals(string)) {
				return availableAbilities.get(i);
			}
		}
		return null;
	}

	public Champion getCurrentChampion() {
		if (((Champion) (turnOrder.peekMin())).getCurrentHP() > 0)
			return (Champion) turnOrder.peekMin();
		else
			turnOrder.remove();
		return (Champion) turnOrder.peekMin();
	}

	public Player checkGameOver() {
		int count1 = 0;
		int count2 = 0;
		for (int i = 0; i < this.getFirstPlayer().getTeam().size(); i++) {
			if (this.getFirstPlayer().getTeam().get(i).getCondition() == Condition.KNOCKEDOUT)
				count1++;
		}
		for (int i = 0; i < this.getSecondPlayer().getTeam().size(); i++) {
			if (this.getSecondPlayer().getTeam().get(i).getCondition() == Condition.KNOCKEDOUT)
				count2++;
		}
		if (count1 == this.getFirstPlayer().getTeam().size())
			return this.secondPlayer;
		else if (count2 == this.getSecondPlayer().getTeam().size())
			return this.firstPlayer;
		else
			return null;
	}

	public void move(Direction d) throws NotEnoughResourcesException, UnallowedMovementException {
		for (int i = 0; i < this.getCurrentChampion().getAppliedEffects().size(); i++) {
			if (this.getCurrentChampion().getAppliedEffects().get(i) instanceof Root) {
				this.getCurrentChampion().getAppliedEffects().remove(i);
				throw new UnallowedMovementException("Current champion is rooted!");

			}
		}

		int x = this.getCurrentChampion().getLocation().x;
		int y = this.getCurrentChampion().getLocation().y;
		int z = this.getCurrentChampion().getLocation().x;
		int w = this.getCurrentChampion().getLocation().y;
		if (d == Direction.LEFT && (y - 1) >= 0)
			y = y - 1;
		else if (d == Direction.RIGHT && (y + 1) <= 4)
			y++;
		else if (d == Direction.UP && (x + 1) <= 4)
			x++;
		else if (d == Direction.DOWN && (x - 1) >= 0)
			x--;

		Point p = new Point(x, y);
		if (board[x][y] == null) {
			if (this.getCurrentChampion().getCurrentActionPoints() >= 1) {
				this.getCurrentChampion().setLocation((p));
				board[x][y] = this.getCurrentChampion();
				board[z][w] = null;

				this.getCurrentChampion()
						.setCurrentActionPoints(this.getCurrentChampion().getCurrentActionPoints() - 1);

			} else
				throw new NotEnoughResourcesException("Current champion doesn't have enough action points to move!");

		} else
			throw new UnallowedMovementException("Unallowed movement!");

	}

	public void castAbility(Ability a, Direction d)
			throws NotEnoughResourcesException, AbilityUseException, CloneNotSupportedException {
		validateCastAbility(a);
		ArrayList<Point> possiblePoints = new ArrayList<Point>();
		int currx = (int) getCurrentChampion().getLocation().getX();
		int curry = (int) getCurrentChampion().getLocation().getY();
		for (int i = 0; i < a.getCastRange(); i++) {
			if (d == Direction.UP) {
				currx++;
				if (currx == BOARDHEIGHT)
					break;
			} else if (d == Direction.DOWN) {
				currx--;
				if (currx < 0)
					break;
			} else if (d == Direction.LEFT) {
				curry--;
				if (curry < 0)
					break;
			} else if (d == Direction.RIGHT) {
				curry++;
				if (curry == BOARDWIDTH)
					break;
			}
			possiblePoints.add(new Point(currx, curry));
		}
		ArrayList<Damageable> targets = prepareTargetsFromPoints(a, possiblePoints);

		a.execute(targets);
		getCurrentChampion().setMana(getCurrentChampion().getMana() - a.getManaCost());
		getCurrentChampion()
				.setCurrentActionPoints(getCurrentChampion().getCurrentActionPoints() - a.getRequiredActionPoints());

		a.setCurrentCooldown(a.getBaseCooldown());
		cleanup(targets);

	}

	private ArrayList<Damageable> prepareTargetsFromPoints(Ability a, ArrayList<Point> possiblePoints) {
		ArrayList<Damageable> targets = new ArrayList<Damageable>();
		for (Point p : possiblePoints) {
			int x = (int) p.getX();
			int y = (int) p.getY();
			if (x >= 0 && x < BOARDHEIGHT && y >= 0 && y < BOARDWIDTH) {
				Object o = board[x][y];
				if (o != null) {
					if (o instanceof Cover) {
						if (a instanceof DamagingAbility)
							targets.add((Damageable) o);
					} else {

						boolean friendly = ((firstPlayer.getTeam().contains(getCurrentChampion())
								&& firstPlayer.getTeam().contains(o))
								|| ((secondPlayer.getTeam().contains(getCurrentChampion())
										&& secondPlayer.getTeam().contains(o)))) ? true : false;
						if (a instanceof HealingAbility && friendly)
							targets.add((Damageable) o);
						else if (a instanceof DamagingAbility && !friendly) {
							Champion c = (Champion) o;
							if (hasEffect(c, "Shield")) {
								for (Effect e : c.getAppliedEffects()) {
									if (e instanceof Shield) {
										c.getAppliedEffects().remove(e);
										break;
									}
								}
							} else
								targets.add((Damageable) o);
						} else if (a instanceof CrowdControlAbility
								&& ((CrowdControlAbility) a).getEffect().getType() == EffectType.DEBUFF && !friendly)
							targets.add((Damageable) o);
						else if (a instanceof CrowdControlAbility
								&& ((CrowdControlAbility) a).getEffect().getType() == EffectType.BUFF && friendly)
							targets.add((Damageable) o);
					}
				}
			}
		}
		return targets;
	}

	public void castAbility(Ability a, int x, int y) throws NotEnoughResourcesException, AbilityUseException,
			InvalidTargetException, CloneNotSupportedException {
		validateCastAbility(a);
		if (board[x][y] == null)
			throw new InvalidTargetException("You can not cast an ability on an empty cell");
		int distance = Math.abs((int) getCurrentChampion().getLocation().getX() - x)
				+ Math.abs((int) getCurrentChampion().getLocation().getY() - y);
		if (distance > a.getCastRange())
			throw new AbilityUseException("Target out of the ability's cast range");

		if (board[x][y] instanceof Cover && !(a instanceof DamagingAbility))
			throw new InvalidTargetException("Covers can only be damaged");
		if (board[x][y] instanceof Champion) {
			Champion target = (Champion) board[x][y];
			boolean friendly = ((firstPlayer.getTeam().contains(getCurrentChampion())
					&& firstPlayer.getTeam().contains(target))
					|| ((secondPlayer.getTeam().contains(getCurrentChampion())
							&& secondPlayer.getTeam().contains(target)))) ? true : false;
			if (friendly && a instanceof DamagingAbility)
				throw new InvalidTargetException("Can not cast damaging ability on friendly targets");
			if (friendly && a instanceof CrowdControlAbility
					&& ((CrowdControlAbility) a).getEffect().getType() == EffectType.DEBUFF)
				throw new InvalidTargetException("Can not debuff friendly targets");
			if (!friendly && a instanceof HealingAbility)
				throw new InvalidTargetException("Can not cast healing ability on enemy targets");
			if (!friendly && a instanceof CrowdControlAbility
					&& ((CrowdControlAbility) a).getEffect().getType() == EffectType.BUFF)
				throw new InvalidTargetException("Can not buff enemy targets");
		}
		ArrayList<Damageable> targets = new ArrayList<Damageable>();
		if (board[x][y] instanceof Cover && a instanceof DamagingAbility)
			targets.add((Cover) board[x][y]);
		else {
			Champion c = (Champion) board[x][y];
			if (hasEffect(c, "Shield")) {
				for (Effect e : c.getAppliedEffects()) {
					if (e instanceof Shield) {
						c.getAppliedEffects().remove(e);
						break;
					}
				}
			} else
				targets.add(c);
		}
		a.execute(targets);
		getCurrentChampion().setMana(getCurrentChampion().getMana() - a.getManaCost());
		getCurrentChampion()
				.setCurrentActionPoints(getCurrentChampion().getCurrentActionPoints() - a.getRequiredActionPoints());
		a.setCurrentCooldown(a.getBaseCooldown());
		cleanup(targets);
	}

	public void attack(Direction d)
			throws NotEnoughResourcesException, InvalidTargetException, ChampionDisarmedException {

		for (int i = 0; i < this.getCurrentChampion().getAppliedEffects().size(); i++) {
			if (this.getCurrentChampion().getAppliedEffects().get(i) instanceof Disarm) {
				throw new ChampionDisarmedException("Champion is disarmed");
			}
		}

		if (this.getCurrentChampion().getCurrentActionPoints() < 2) {
			throw new NotEnoughResourcesException("Not enough action points!");
		}

		Damageable D = null;

		int x = this.getCurrentChampion().getLocation().x;
		int y = this.getCurrentChampion().getLocation().y;

		for (int i = 1; i <= this.getCurrentChampion().getAttackRange(); i++) {
			if (d == Direction.LEFT && (y - i) >= 0)
				D = (Damageable) board[x][y - i];
			else if (d == Direction.RIGHT && (y + i) <= 4)
				D = (Damageable) board[x][y + i];
			else if (d == Direction.UP && (x + i) <= 4)
				D = (Damageable) board[x + i][y];
			else if ((x - i) >= 0)
				D = (Damageable) board[x - i][y];

			if (D != null) {

				int x1 = D.getLocation().x;
				int y1 = D.getLocation().y;
				if (board[x1][y1] instanceof Cover
						|| (checkTeam((Champion) board[x1][y1]) != checkTeam(this.getCurrentChampion())))
					break;
			}
		}

		if (D == null)
			return;

		if (D instanceof Champion && (checkTeam((Champion) D) == checkTeam(this.getCurrentChampion())))
			return;

		int k = 0;
		x = D.getLocation().x;
		y = D.getLocation().y;

		if (D instanceof Champion) {
			Champion C = (Champion) D;

			for (int i = 0; i < C.getAppliedEffects().size(); i++) {
				if (C.getAppliedEffects().get(i) instanceof Shield) {
					k = 3;
					C.getAppliedEffects().get(i).remove(C);
					C.getAppliedEffects().remove(i);
					break;
				}
			}
			if (k != 3) {
				for (int i = 0; i < C.getAppliedEffects().size(); i++) {
					if (C.getAppliedEffects().get(i) instanceof Dodge) {
						k = 2;
						break;
					}
				}
			}

		}

		if (k == 2) {
			int z = (int) (Math.random() * 2);
			if (z == 0)
				k = 0;
			else
				k = 3;
		}

		if (D != null) {
			switch (k) {
			case 0:
				this.getCurrentChampion()
						.setCurrentActionPoints(this.getCurrentChampion().getCurrentActionPoints() - 2);
				if (board[x][y] instanceof Cover) {

					Cover q = (Cover) board[x][y];
					q.setCurrentHP(q.getCurrentHP() - this.getCurrentChampion().getAttackDamage());
					if (q.getCurrentHP() <= 0)
						board[x][y] = null;
				} else if (this.getCurrentChampion() instanceof Hero && board[x][y] instanceof Hero) {
					((Champion) D).setCurrentHP(D.getCurrentHP() - this.getCurrentChampion().getAttackDamage());
					if (((Champion) (board[x][y])).getCurrentHP() <= 0) {

						if (this.getFirstPlayer().getTeam().contains(board[x][y])) {
							this.getFirstPlayer().getTeam().remove(board[x][y]);
							((Champion) board[x][y]).setCondition(Condition.KNOCKEDOUT);
						} else {
							this.getSecondPlayer().getTeam().remove(board[x][y]);
							((Champion) board[x][y]).setCondition(Condition.KNOCKEDOUT);
						}
						board[x][y] = null;
					}
				} else if (this.getCurrentChampion() instanceof AntiHero && board[x][y] instanceof AntiHero) {
					((Champion) D).setCurrentHP(D.getCurrentHP() - this.getCurrentChampion().getAttackDamage());
					if (((Champion) D).getCurrentHP() <= 0) {
						board[x][y] = null;
						if (this.getFirstPlayer().getTeam().contains(board[x][y])) {
							this.getFirstPlayer().getTeam().remove(board[x][y]);
							((Champion) board[x][y]).setCondition(Condition.KNOCKEDOUT);

						} else {
							this.getSecondPlayer().getTeam().remove(board[x][y]);
							((Champion) board[x][y]).setCondition(Condition.KNOCKEDOUT);
						}
						board[x][y] = null;
					}
				} else if (this.getCurrentChampion() instanceof Villain && board[x][y] instanceof Villain) {
					((Champion) D).setCurrentHP(D.getCurrentHP() - this.getCurrentChampion().getAttackDamage());
					if (((Champion) D).getCurrentHP() <= 0) {

						if (this.getFirstPlayer().getTeam().contains(board[x][y])) {
							this.getFirstPlayer().getTeam().remove(board[x][y]);
							((Champion) board[x][y]).setCondition(Condition.KNOCKEDOUT);
						} else {
							this.getSecondPlayer().getTeam().remove(board[x][y]);
							((Champion) board[x][y]).setCondition(Condition.KNOCKEDOUT);
						}
						board[x][y] = null;
					}
				} else {
					int h = (int) this.getCurrentChampion().getAttackDamage() / 2;

					((Champion) D).setCurrentHP(D.getCurrentHP() - ((this.getCurrentChampion().getAttackDamage() + h)));
					if (((Champion) D).getCurrentHP() <= 0) {

						if (this.getFirstPlayer().getTeam().contains(board[x][y])) {
							this.getFirstPlayer().getTeam().remove(board[x][y]);
							((Champion) board[x][y]).setCondition(Condition.KNOCKEDOUT);

						} else {
							this.getSecondPlayer().getTeam().remove(board[x][y]);
							((Champion) board[x][y]).setCondition(Condition.KNOCKEDOUT);
						}
						board[x][y] = null;
					}
				}
				break;
			case 3:
				this.getCurrentChampion()
						.setCurrentActionPoints(this.getCurrentChampion().getCurrentActionPoints() - 2);
				break;

			}

		}
		PriorityQueue temp = new PriorityQueue(6);
		while (!turnOrder.isEmpty()) {

			if (((Champion) turnOrder.peekMin()).getCurrentHP() > 0) {
				temp.insert(((Champion) turnOrder.remove()));
			} else
				turnOrder.remove();

		}
		while (!temp.isEmpty()) {
			turnOrder.insert(temp.remove());
		}
	}

	private int checkTeam(Damageable currentChampion) {
		for (int i = 0; i < this.firstPlayer.getTeam().size(); i++) {
			if (this.firstPlayer.getTeam().get(i) == currentChampion)
				return 1;
		}
		return 2;
	}

	private int Manhattan(Champion c) {
		int x1 = this.getCurrentChampion().getLocation().x;
		int y1 = this.getCurrentChampion().getLocation().y;
		int x2 = c.getLocation().x;
		int y2 = c.getLocation().x;
		return Math.abs(x1 - x2) + Math.abs(y1 - y2);

	}

	

	private void prepareChampionTurns() {
		for (int i = 0; i < firstPlayer.getTeam().size(); i++) {
			turnOrder.insert(firstPlayer.getTeam().get(i));
		}

		for (int i = 0; i < secondPlayer.getTeam().size(); i++) {
			turnOrder.insert(secondPlayer.getTeam().get(i));
		}
	}

	public void endTurn() {
		turnOrder.remove();
		if (turnOrder.isEmpty())
			prepareChampionTurns();
		while (!turnOrder.isEmpty() && hasEffect((Champion) turnOrder.peekMin(), "Stun")) {
			Champion current = (Champion) turnOrder.peekMin();
			updateTimers(current);
			turnOrder.remove();
			if (turnOrder.isEmpty())
				this.prepareChampionTurns();
		}
		Champion current = (Champion) turnOrder.peekMin();
		updateTimers(current);
		current.setCurrentActionPoints(current.getMaxActionPointsPerTurn());
	}

	private void updateTimers(Champion current) {
		int i = 0;
		while (i < current.getAppliedEffects().size()) {
			Effect e = current.getAppliedEffects().get(i);
			e.setDuration(e.getDuration() - 1);
			if (e.getDuration() == 0) {
				current.getAppliedEffects().remove(e);
				e.remove(current);

			} else
				i++;
		}
		int j = 0;
		while (j < current.getAbilities().size()) {
			Ability e = current.getAbilities().get(j);
			e.setCurrentCooldown(e.getCurrentCooldown() - 1);

			j++;
		}
	}

	private boolean hasEffect(Champion currentChampion, String s) {
		for (Effect e : currentChampion.getAppliedEffects()) {
			if (e.getName().equals(s))
				return true;
		}
		return false;
	}

	public void useLeaderAbility()
			throws LeaderNotCurrentException, LeaderAbilityAlreadyUsedException, CloneNotSupportedException {
		if (getCurrentChampion() != firstPlayer.getLeader() && getCurrentChampion() != secondPlayer.getLeader())
			throw new LeaderNotCurrentException("The current champion is not a leader");
		if (getCurrentChampion() == firstPlayer.getLeader() && firstLeaderAbilityUsed)
			throw new LeaderAbilityAlreadyUsedException("This leader already used his ability");
		if (getCurrentChampion() == secondPlayer.getLeader() && secondLeaderAbilityUsed)
			throw new LeaderAbilityAlreadyUsedException("This leader already used his ability");
		ArrayList<Champion> targets = new ArrayList<Champion>();
		if (getCurrentChampion() instanceof Hero) {
			ArrayList<Champion> team = getCurrentChampion() == firstPlayer.getLeader() ? firstPlayer.getTeam()
					: secondPlayer.getTeam();
			targets.add(getCurrentChampion());
			for (Champion c : team)
				targets.add(c);
		} else if (getCurrentChampion() instanceof AntiHero) {
			for (Champion c : firstPlayer.getTeam()) {
				if (c != firstPlayer.getLeader())
					targets.add(c);
			}
			for (Champion c : secondPlayer.getTeam()) {
				if (c != secondPlayer.getLeader())
					targets.add(c);
			}
		} else if (getCurrentChampion() instanceof Villain) {
			ArrayList<Champion> enemies = getCurrentChampion() == firstPlayer.getLeader() ? secondPlayer.getTeam()
					: firstPlayer.getTeam();
			for (Champion c : enemies) {
				if (c.getCurrentHP() < (0.3 * c.getMaxHP()))
					targets.add(c);
			}
		}
		getCurrentChampion().useLeaderAbility(targets);
		if (getCurrentChampion() == firstPlayer.getLeader())
			firstLeaderAbilityUsed = true;
		else if (getCurrentChampion() == secondPlayer.getLeader())
			secondLeaderAbilityUsed = true;
	}

	public boolean isLeader(Champion C) {
		return (this.getFirstPlayer().getLeader() == C || this.getSecondPlayer().getLeader() == C);
	}

	public void castAbility(Ability a)
			throws NotEnoughResourcesException, AbilityUseException, CloneNotSupportedException {
		validateCastAbility(a);
		ArrayList<Damageable> targets = new ArrayList<Damageable>();
		if (a.getCastArea() == AreaOfEffect.SELFTARGET) {
			targets.add(getCurrentChampion());
		} else if (a.getCastArea() == AreaOfEffect.TEAMTARGET) {
			ArrayList<Champion> team = null;
			if (a instanceof DamagingAbility || (a instanceof CrowdControlAbility
					&& ((CrowdControlAbility) a).getEffect().getType() == EffectType.DEBUFF)) {
				if (firstPlayer.getTeam().contains(getCurrentChampion()))
					team = secondPlayer.getTeam();
				else
					team = firstPlayer.getTeam();
			} else if (a instanceof HealingAbility
					|| (a instanceof CrowdControlAbility && (a instanceof CrowdControlAbility
							&& ((CrowdControlAbility) a).getEffect().getType() == EffectType.BUFF))) {
				if (firstPlayer.getTeam().contains(getCurrentChampion()))
					team = firstPlayer.getTeam();
				else
					team = secondPlayer.getTeam();
			}
			for (Champion c : team) {
				int x = (int) c.getLocation().getX();
				int y = (int) c.getLocation().getY();
				int distance = Math.abs((int) getCurrentChampion().getLocation().getX() - x)
						+ Math.abs((int) getCurrentChampion().getLocation().getY() - y);
				if (distance <= a.getCastRange())
					targets.add(c);
			}
		} else if (a.getCastArea() == AreaOfEffect.SURROUND) {
			ArrayList<Point> possiblePoints = new ArrayList<Point>();
			int currx = (int) getCurrentChampion().getLocation().getX();
			int curry = (int) getCurrentChampion().getLocation().getY();
			possiblePoints.add(new Point(currx + 1, curry));
			possiblePoints.add(new Point(currx - 1, curry));
			possiblePoints.add(new Point(currx, curry + 1));
			possiblePoints.add(new Point(currx, curry - 1));
			possiblePoints.add(new Point(currx + 1, curry - 1));
			possiblePoints.add(new Point(currx + 1, curry + 1));
			possiblePoints.add(new Point(currx - 1, curry - 1));
			possiblePoints.add(new Point(currx - 1, curry + 1));
			targets = prepareTargetsFromPoints(a, possiblePoints);
		}

		a.execute(targets);
		getCurrentChampion().setMana(getCurrentChampion().getMana() - a.getManaCost());
		getCurrentChampion()
				.setCurrentActionPoints(getCurrentChampion().getCurrentActionPoints() - a.getRequiredActionPoints());
		cleanup(targets);
		a.setCurrentCooldown(a.getBaseCooldown());

	}
	private void cleanup(ArrayList<Damageable> targets) {
		for (Damageable c : targets) {
			if (c.getCurrentHP() == 0) {
				board[(int) c.getLocation().getX()][(int) c.getLocation().getY()] = null;
				firstPlayer.getTeam().remove(c);
				secondPlayer.getTeam().remove(c);
				ArrayList<Champion> temp = new ArrayList<Champion>();
				while (!turnOrder.isEmpty()) {
					if (turnOrder.peekMin() == c) {
						turnOrder.remove();
						break;
					} else
						temp.add((Champion) turnOrder.remove());
				}
				while (!temp.isEmpty())
					turnOrder.insert(temp.remove(0));

			}
		}

	}

	private void validateCastAbility(Ability a) throws NotEnoughResourcesException, AbilityUseException {
		if (getCurrentChampion().getMana() < a.getManaCost())
			throw new NotEnoughResourcesException(
					"you need at least " + a.getManaCost() + " mana to cast this ability");
		else if (getCurrentChampion().getCurrentActionPoints() < a.getRequiredActionPoints())
			throw new NotEnoughResourcesException(
					"you need at least " + a.getRequiredActionPoints() + " action points to cast this ability");
		else if (hasEffect(getCurrentChampion(), "Silence"))
			throw new AbilityUseException("You can not cast an ability while being silenced");
		else if (a.getCurrentCooldown() > 0)
			throw new AbilityUseException("You can not use an ability while it is in cooldown");
	}

	public ArrayList<Damageable> surround() {
		ArrayList<Damageable> targets = new ArrayList<>();
		double range = Math.sqrt(2);
		for (int i = 0; i <= 4; i++) {
			for (int j = 0; j <= 4; j++) {
				if (board[i][j] != null) {
					Damageable d = (Damageable) board[i][j];
					if (this.getCurrentChampion().getLocation().distance(d.getLocation()) <= range
							&& d != this.getCurrentChampion())
						targets.add(d);
				}
			}
		}
		return targets;
	}

	public ArrayList<Damageable> directionalchampions(Champion C, Ability a, Direction d) {
		ArrayList<Damageable> targets = new ArrayList<>();
		int range = a.getCastRange();
		Damageable F = null;
		int x = this.getCurrentChampion().getLocation().x;
		int y = this.getCurrentChampion().getLocation().y;
		if (d == Direction.UP) {
			for (int i = 1; i <= range; i++) {
				int x1 = x + i;
				if (x1 > 4)
					break;
				if (board[x1][y] != null) {
					F = ((Damageable) board[x1][y]);
					targets.add(F);
				}
			}
		} else if (d == Direction.DOWN) {
			for (int i = 1; i <= range; i++) {
				int x2 = x - i;
				if (x2 < 0)
					break;
				if (board[x2][y] != null) {
					F = ((Damageable) board[x2][y]);
					targets.add(F);
				}
			}
		} else if (d == Direction.RIGHT) {
			for (int i = 1; i <= range; i++) {
				int y1 = y + i;
				if (y1 > 4)
					break;
				if (board[x][y1] != null) {
					F = ((Damageable) board[x][y1]);
					targets.add(F);
				}
			}
		} else {
			for (int i = 1; i <= range; i++) {
				int y2 = y - i;
				if (y2 < 0)
					break;
				if (board[x][y2] != null) {
					F = ((Damageable) board[x][y2]);
					targets.add(F);
				}
			}
		}

		return targets;
	}

}
