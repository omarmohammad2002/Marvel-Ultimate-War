package model.world;

import java.util.ArrayList;

import model.effects.Effect;
import model.effects.Stun;

public class AntiHero extends Champion {

	public AntiHero(String name, int maxHp, int mana, int maxActions, int speed, int attackRange, int attackDamage) {
		super(name, maxHp, mana, maxActions, speed, attackRange, attackDamage);
	}

	public void useLeaderAbility(ArrayList<Champion> targets) throws CloneNotSupportedException {
		for (int i = 0; i < targets.size(); i++) {
			Effect S = new Stun(2);
			((Champion) (targets.get(i))).getAppliedEffects().add(S);
			S.apply((Champion) targets.get(i));

		}
	}
}
