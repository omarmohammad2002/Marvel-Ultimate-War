package model.world;

import java.util.ArrayList;

public class Villain extends Champion {

	public Villain(String name, int maxHp, int mana, int maxActions, int speed, int attackRange, int attackDamage) {
		super(name, maxHp, mana, maxActions, speed, attackRange, attackDamage);
	}

	public void useLeaderAbility(ArrayList<Champion> targets) {
		for (int i = 0; i < targets.size(); i++) {
			Champion C = (Champion) targets.get(i);

			C.setCondition(Condition.KNOCKEDOUT);

		}
	}
}
