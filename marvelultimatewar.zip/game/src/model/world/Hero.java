package model.world;

import model.effects.*;
import java.util.ArrayList;

public class Hero extends Champion {

	public Hero(String name, int maxHp, int mana, int maxActions, int speed, int attackRange, int attackDamage) {
		super(name, maxHp, mana, maxActions, speed, attackRange, attackDamage);
	}

	public void useLeaderAbility(ArrayList<Champion> targets) throws CloneNotSupportedException {
		for (int i = 0; i < targets.size(); i++) {
			Champion C = (Champion) targets.get(i);
			ArrayList<Effect> toBeRemoved = new ArrayList<Effect>();
			for (int j = 0; j < C.getAppliedEffects().size(); j++) {
				if (C.getAppliedEffects().get(j).getType() == EffectType.DEBUFF) {
					toBeRemoved.add(C.getAppliedEffects().get(j));
				}
			}
			for (int j = 0; j < toBeRemoved.size(); j++) {
				C.getAppliedEffects().remove(toBeRemoved.get(j));
			}
			Effect E = new Embrace(2);
			C.getAppliedEffects().add(E);
			E.apply(((Champion) (targets.get(i))));

		}
	}

}
