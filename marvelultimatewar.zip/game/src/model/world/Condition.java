package model.world;

public enum Condition {
	ACTIVE, INACTIVE,ROOTED, KNOCKEDOUT
}
