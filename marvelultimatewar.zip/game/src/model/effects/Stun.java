package model.effects;

import model.world.Champion;
import model.world.Condition;

public class Stun extends Effect {
	public Stun (int duration) {
		super("Stun",duration,EffectType.DEBUFF) ; 
}
	public void apply(Champion c) {
		c.setCondition(Condition.INACTIVE);
		
	}
	public void remove(Champion c) {
		int counter=0;
		int counter2 = 0; 
		  
			  for(int i=0;i<c.getAppliedEffects().size();i++) {  
			  if(c.getAppliedEffects().get(i) instanceof Stun) {
				  counter++;	  
				  }
			  if(c.getAppliedEffects().get(i) instanceof Root) {
				  counter2++;	  }
			  }
			  
			  if (counter==0 && counter2==0 ) {
				  c.setCondition(Condition.ACTIVE);
			  }
			  else if(counter>0){
				  c.setCondition(Condition.INACTIVE);
			  }
			  else if (counter2>0 && counter==0)
				  c.setCondition(Condition.ROOTED);
}
	}
	

