package model.effects;

import java.util.ArrayList;

import model.world.Champion;
import model.world.Condition;

public class Root extends Effect {
	public Root (int duration) {
		super("Root",duration,EffectType.DEBUFF) ; 
}
	public void apply(Champion c) throws CloneNotSupportedException {
		if (c.getCondition()== Condition.INACTIVE) {
			
		}
		else
			c.setCondition(Condition.ROOTED);
		
		
		
	}
	
	public void remove(Champion c) {
		
		int counter=0;		  
		  
			  for(int i=0;i<c.getAppliedEffects().size();i++) {  
				  if(c.getAppliedEffects().get(i) instanceof Root) 
					  counter++;	  }
				
			 
			 
			 if (counter>0) 
				 c.setCondition(Condition.ROOTED);
		}
}



