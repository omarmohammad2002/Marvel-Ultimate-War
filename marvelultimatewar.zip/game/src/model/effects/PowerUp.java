package model.effects;
import model.abilities.DamagingAbility;
import model.abilities.HealingAbility;

import model.world.Champion;
public class PowerUp extends Effect{
	public PowerUp (int duration) {
		super("PowerUp",duration,EffectType.BUFF) ; }
	public void apply(Champion c) {
		for(int i=0;i< c.getAbilities().size();i++) {
			if(c.getAbilities().get(i) instanceof HealingAbility) {
				HealingAbility temp=(HealingAbility) c.getAbilities().get(i);
			 temp.setHealAmount((int)(temp.getHealAmount()*1.2));
		}
			else if (c.getAbilities().get(i) instanceof DamagingAbility) {
				DamagingAbility tmp = (DamagingAbility) c.getAbilities().get(i);
				tmp.setDamageAmount((int)(tmp.getDamageAmount()*1.2));
			}
		}
		
	}
	public void remove(Champion c) {
		for(int i=0;i< c.getAbilities().size();i++) { 
			if(c.getAbilities().get(i) instanceof HealingAbility) {
				HealingAbility temp=(HealingAbility) c.getAbilities().get(i);
			 temp.setHealAmount((int)(temp.getHealAmount()/1.2));
		}
			else if (c.getAbilities().get(i) instanceof DamagingAbility) {
				DamagingAbility tmp = (DamagingAbility) c.getAbilities().get(i);
				tmp.setDamageAmount((int)(tmp.getDamageAmount()/1.2));
			}
		
	}
	}
	

}
