package model.abilities;

import java.util.ArrayList;

import model.effects.Shield;
import model.world.Champion;
import model.world.Damageable;

public class DamagingAbility extends Ability {
	private int damageAmount ; 
public DamagingAbility(String name, int cost, int baseCooldown, int castRange, AreaOfEffect area, int required, int damageAmount) {
		super(name, cost, baseCooldown, castRange, area, required);
		this.damageAmount=damageAmount ; 
	}

public String toString() {
	String s ="\n------------------\n";
	s+="Name: "+getName()+"\n";
	s+="Type: "+getType()+"\n";
	s+="Cost: "+getManaCost()+"\n";
	s+="Cooldown: "+getBaseCooldown()+"\n";
	s+="Cast Range: "+getCastRange()+"\n";
	s+="Area Of Effect: "+getAreaOfEffect()+"\n";
	s+="Required Action Points: "+getRequiredActionPoints()+"\n";
	s+="Damage Amount: "+getDamageAmount()+"\n";
	return s;
}
public int getDamageAmount() {
	return damageAmount;
}
public void setDamageAmount(int damageAmount) {
	this.damageAmount = damageAmount;
}
@Override
public void execute(ArrayList<Damageable> targets) {
	// TODO Auto-generated method stub
	for (int i = 0 ; i<targets.size() ; i ++ ) {
		int d=damageAmount;		
		int cH=targets.get(i).getCurrentHP()-d;
		targets.get(i).setCurrentHP(cH);
		

	}

}
}
