package model.abilities;
import java.util.ArrayList;

import model.world.*; ; 

public abstract class Ability {
private String name ;
private int manaCost ; 
private int baseCooldown ; 
private int currentCooldown ; 
private int castRange ; 
private int requiredActionPoints ; 
private AreaOfEffect castArea ; 
public Ability (String name, int cost, int baseCooldown, int castRange, AreaOfEffect area, int required ) {
	this.name = name ; 
	this.manaCost = cost ; 
	this.baseCooldown = baseCooldown ; 
	this.castRange = castRange ; 
	this.castArea = area ; 
	this.requiredActionPoints = required ; 
}
public String getType() {
	if(this instanceof CrowdControlAbility)return "CrowdControlAbility";
	else if(this instanceof HealingAbility)return "Healing Ability";
	else return "Damaging Ability";
}

public String getAreaOfEffect() {
	if(castArea == AreaOfEffect.DIRECTIONAL)return "Directional";
	else if(castArea == AreaOfEffect.SELFTARGET)return "SelfTarget";
	else if(castArea == AreaOfEffect.SINGLETARGET)return "SingleTarget";
	else if(castArea == AreaOfEffect.SURROUND)return "Surround";
	else return "TeamTarget";
}

public String getName() {
	return name;
}
public int getManaCost() {
	return manaCost;
}
public int getBaseCooldown() {
	return baseCooldown;
}
public int getCurrentCooldown() {
	return currentCooldown;
}
public void setCurrentCooldown(int currentCoolDown) {
	if (currentCoolDown < 0)
		currentCoolDown = 0;
	else if (currentCoolDown > baseCooldown)
		currentCoolDown = baseCooldown;
	this.currentCooldown = currentCoolDown;
}
public int getCastRange() {
	return castRange;
}
public int getRequiredActionPoints() {
	return requiredActionPoints;
}

public AreaOfEffect getCastArea() {
	return castArea;
}
public abstract void execute(ArrayList<Damageable> targets) throws CloneNotSupportedException ; 


}

