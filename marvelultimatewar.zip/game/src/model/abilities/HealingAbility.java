package model.abilities;

import java.util.ArrayList;

import model.world.Champion;
import model.world.Damageable;

public class HealingAbility extends Ability{
	private int healAmount ; 
public HealingAbility(String name, int cost, int baseCooldown, int castRange, AreaOfEffect area, int required, int healAmount) {
		super(name, cost, baseCooldown, castRange, area, required);
		this.healAmount=healAmount ; 
	}

public String toString() {
	String s ="\n------------------\n";
	s+="Name: "+getName()+"\n";
	s+="Type: "+getType()+"\n";
	s+="Cost: "+getManaCost()+"\n";
	s+="Cooldown: "+getBaseCooldown()+"\n";
	s+="Cast Range: "+getCastRange()+"\n";
	s+="Area Of Effect: "+getAreaOfEffect()+"\n";
	s+="Required Action Points: "+getRequiredActionPoints()+"\n";
	s+="Healing Amount: "+getHealAmount()+"\n";
	return s;
}
public int getHealAmount() {
	return healAmount;
}
public void setHealAmount(int healAmount) {
	this.healAmount = healAmount;
}
@Override
public void execute(ArrayList<Damageable> targets) {
	// TODO Auto-generated method stub
	for (int i = 0 ; i<targets.size() ; i ++ ) {
		if (targets.get(i) instanceof Champion ) {
		int x = targets.get(i).getCurrentHP() + healAmount ; 
		targets.get(i).setCurrentHP(x);
	}
}
}
}
